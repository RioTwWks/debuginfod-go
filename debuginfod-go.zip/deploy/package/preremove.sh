#!/bin/sh
set -e

if command -v systemctl >/dev/null 2>&1; then
	systemctl stop debuginfod-go.service 2>/dev/null || true
	systemctl disable debuginfod-go.service 2>/dev/null || true
fi
