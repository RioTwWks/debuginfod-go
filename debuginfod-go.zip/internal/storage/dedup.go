package storage

import (
	"database/sql"
	"errors"
	"fmt"
	"time"
)

// DedupBuildStatus — статус обработки каталога build_*.
type DedupBuildStatus string

const (
	DedupStatusPending    DedupBuildStatus = "pending"
	DedupStatusProcessing DedupBuildStatus = "processing"
	DedupStatusDone       DedupBuildStatus = "done"
	DedupStatusError      DedupBuildStatus = "error"
	DedupStatusSkipped    DedupBuildStatus = "skipped"
)

// DedupStorageKind — как хранится файл после dedup.
type DedupStorageKind string

const (
	DedupKindFull       DedupStorageKind = "full"
	DedupKindBase       DedupStorageKind = "base"
	DedupKindDelta      DedupStorageKind = "delta"
	DedupKindCompressed DedupStorageKind = "compressed"
	DedupKindRef        DedupStorageKind = "ref"
)

// DedupProject — проект Quik (QuikServer, Front).
type DedupProject struct {
	ID   int64
	Name string
}

// DedupBuildDir — каталог build_* на диске.
type DedupBuildDir struct {
	ID          int64
	ProjectID   int64
	ProjectName string
	DirPath     string
	DirBuildNum int
	Status      DedupBuildStatus
	ErrorMsg    string
	ProcessedAt time.Time
}

// DedupFile — метаданные одного .debug для dedup.
type DedupFile struct {
	ID           int64
	BuildDirID   int64
	ProjectName  string
	FilePath     string
	Filename     string
	FileStem     string
	Version      string
	FileBuildNum int
	CommitTag    string
	StorageKind    DedupStorageKind
	BaseFileID     sql.NullInt64
	BlobPath       string // колонка delta_path в БД (историческое имя)
	SHA256         string
	OriginalSize   int64
	CompressedSize int64
	Status       DedupBuildStatus
	ErrorMsg     string
}

// DedupGroupKey — ключ группировки (метаданные, для UI/отчётов).
type DedupGroupKey struct {
	Project   string
	FileStem  string
	Version   string
	CommitTag string
}

func dedupSchemaSQLite() string {
	return `
		CREATE TABLE IF NOT EXISTS dedup_projects (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			name TEXT NOT NULL UNIQUE
		);

		CREATE TABLE IF NOT EXISTS dedup_build_dirs (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			project_id INTEGER NOT NULL,
			dir_path TEXT NOT NULL UNIQUE,
			dir_build_num INTEGER NOT NULL DEFAULT 0,
			status TEXT NOT NULL DEFAULT 'pending',
			error_msg TEXT NOT NULL DEFAULT '',
			processed_at INTEGER NOT NULL DEFAULT 0,
			FOREIGN KEY (project_id) REFERENCES dedup_projects(id)
		);
		CREATE INDEX IF NOT EXISTS idx_dedup_build_dirs_status ON dedup_build_dirs(status);

		CREATE TABLE IF NOT EXISTS dedup_files (
			id INTEGER PRIMARY KEY AUTOINCREMENT,
			build_dir_id INTEGER NOT NULL,
			file_path TEXT NOT NULL UNIQUE,
			filename TEXT NOT NULL,
			file_stem TEXT NOT NULL,
			version TEXT NOT NULL,
			file_build_num INTEGER NOT NULL,
			commit_tag TEXT NOT NULL DEFAULT '',
			storage_kind TEXT NOT NULL DEFAULT 'full',
			base_file_id INTEGER,
			delta_path TEXT NOT NULL DEFAULT '',
			sha256 TEXT NOT NULL DEFAULT '',
			original_size INTEGER NOT NULL DEFAULT 0,
			compressed_size INTEGER NOT NULL DEFAULT 0,
			status TEXT NOT NULL DEFAULT 'pending',
			error_msg TEXT NOT NULL DEFAULT '',
			FOREIGN KEY (build_dir_id) REFERENCES dedup_build_dirs(id),
			FOREIGN KEY (base_file_id) REFERENCES dedup_files(id)
		);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_status ON dedup_files(status);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_group ON dedup_files(file_stem, version, commit_tag);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_commit_tag ON dedup_files(commit_tag);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_filename ON dedup_files(filename);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_file_stem ON dedup_files(file_stem);
	`
}

func dedupSchemaPostgres() string {
	return `
		CREATE TABLE IF NOT EXISTS dedup_projects (
			id BIGSERIAL PRIMARY KEY,
			name TEXT NOT NULL UNIQUE
		);

		CREATE TABLE IF NOT EXISTS dedup_build_dirs (
			id BIGSERIAL PRIMARY KEY,
			project_id BIGINT NOT NULL REFERENCES dedup_projects(id),
			dir_path TEXT NOT NULL UNIQUE,
			dir_build_num BIGINT NOT NULL DEFAULT 0,
			status TEXT NOT NULL DEFAULT 'pending',
			error_msg TEXT NOT NULL DEFAULT '',
			processed_at BIGINT NOT NULL DEFAULT 0
		);
		CREATE INDEX IF NOT EXISTS idx_dedup_build_dirs_status ON dedup_build_dirs(status);

		CREATE TABLE IF NOT EXISTS dedup_files (
			id BIGSERIAL PRIMARY KEY,
			build_dir_id BIGINT NOT NULL REFERENCES dedup_build_dirs(id),
			file_path TEXT NOT NULL UNIQUE,
			filename TEXT NOT NULL,
			file_stem TEXT NOT NULL,
			version TEXT NOT NULL,
			file_build_num BIGINT NOT NULL,
			commit_tag TEXT NOT NULL DEFAULT '',
			storage_kind TEXT NOT NULL DEFAULT 'full',
			base_file_id BIGINT REFERENCES dedup_files(id),
			delta_path TEXT NOT NULL DEFAULT '',
			sha256 TEXT NOT NULL DEFAULT '',
			original_size BIGINT NOT NULL DEFAULT 0,
			compressed_size BIGINT NOT NULL DEFAULT 0,
			status TEXT NOT NULL DEFAULT 'pending',
			error_msg TEXT NOT NULL DEFAULT ''
		);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_status ON dedup_files(status);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_group ON dedup_files(file_stem, version, commit_tag);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_commit_tag ON dedup_files(commit_tag);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_filename ON dedup_files(filename);
		CREATE INDEX IF NOT EXISTS idx_dedup_files_file_stem ON dedup_files(file_stem);
	`
}

func migrateDedup(db *sql.DB, dialect Dialect) error {
	schema := dedupSchemaSQLite()
	if dialect == DialectPostgres {
		schema = dedupSchemaPostgres()
	}
	if _, err := db.Exec(schema); err != nil {
		return fmt.Errorf("migrate dedup: %w", err)
	}
	if err := migrateDedupColumns(db, dialect); err != nil {
		return err
	}
	if err := migrateDedupMetaTable(db, dialect); err != nil {
		return err
	}
	if err := migrateDedupStrategyOnce(db, dialect); err != nil {
		return err
	}
	for _, stmt := range []string{
		"CREATE INDEX IF NOT EXISTS idx_dedup_files_commit_tag ON dedup_files(commit_tag)",
		"CREATE INDEX IF NOT EXISTS idx_dedup_files_filename ON dedup_files(filename)",
		"CREATE INDEX IF NOT EXISTS idx_dedup_files_file_stem ON dedup_files(file_stem)",
	} {
		if _, err := db.Exec(stmt); err != nil {
			return fmt.Errorf("migrate dedup index: %w", err)
		}
	}
	return nil
}

func migrateDedupMetaTable(db *sql.DB, dialect Dialect) error {
	q := `
		CREATE TABLE IF NOT EXISTS dedup_meta (
			key TEXT PRIMARY KEY,
			value TEXT NOT NULL
		)
	`
	if dialect == DialectPostgres {
		q = `
			CREATE TABLE IF NOT EXISTS dedup_meta (
				key TEXT PRIMARY KEY,
				value TEXT NOT NULL
			)
		`
	}
	_, err := db.Exec(q)
	return err
}

func dedupMetaGet(db *sql.DB, dialect Dialect, key string) (string, bool) {
	var value string
	err := db.QueryRow(rebind(`SELECT value FROM dedup_meta WHERE key = ?`, dialect), key).Scan(&value)
	if err == sql.ErrNoRows {
		return "", false
	}
	if err != nil {
		return "", false
	}
	return value, true
}

func dedupMetaSet(db *sql.DB, dialect Dialect, key, value string) error {
	if dialect == DialectPostgres {
		_, err := db.Exec(rebind(`
			INSERT INTO dedup_meta (key, value) VALUES (?, ?)
			ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
		`, dialect), key, value)
		return err
	}
	_, err := db.Exec(rebind(`
		INSERT OR REPLACE INTO dedup_meta (key, value) VALUES (?, ?)
	`, dialect), key, value)
	return err
}

// migrateDedupStrategyOnce однократно сбрасывает записи при смене стратегии хранения.
func migrateDedupStrategyOnce(db *sql.DB, dialect Dialect) error {
	const migrationKey = "strategy_xdelta_decompress_dwz_v1"
	if v, ok := dedupMetaGet(db, dialect, migrationKey); ok && v == "done" {
		return nil
	}
	q := rebind(`
		UPDATE dedup_files SET
			status = 'pending',
			storage_kind = 'full',
			base_file_id = NULL,
			delta_path = '',
			compressed_size = 0,
			error_msg = ''
		WHERE storage_kind IN ('base', 'delta', 'compressed', 'ref')
	`, dialect)
	if _, err := db.Exec(q); err != nil {
		return err
	}
	return dedupMetaSet(db, dialect, migrationKey, "done")
}

func migrateDedupColumns(db *sql.DB, dialect Dialect) error {
	alters := []string{
		"ALTER TABLE dedup_files ADD COLUMN compressed_size INTEGER NOT NULL DEFAULT 0",
	}
	if dialect == DialectPostgres {
		alters = []string{
			"ALTER TABLE dedup_files ADD COLUMN IF NOT EXISTS compressed_size BIGINT NOT NULL DEFAULT 0",
		}
	}
	for _, q := range alters {
		if _, err := db.Exec(q); err != nil {
			// SQLite: column may already exist
			if dialect != DialectPostgres {
				continue
			}
			return fmt.Errorf("migrate dedup column: %w", err)
		}
	}
	return nil
}

// EnsureDedupProject создаёт проект, если его ещё нет.
func (s *Storage) EnsureDedupProject(name string) (int64, error) {
	if s.dialect == DialectPostgres {
		var id int64
		err := s.db.QueryRow(rebind(`
			INSERT INTO dedup_projects (name) VALUES (?)
			ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name
			RETURNING id
		`, s.dialect), name).Scan(&id)
		if err == nil {
			return id, nil
		}
	}
	_, err := s.db.Exec(rebind(`INSERT OR IGNORE INTO dedup_projects (name) VALUES (?)`, s.dialect), name)
	if err != nil {
		return 0, err
	}
	var id int64
	err = s.db.QueryRow(rebind(`SELECT id FROM dedup_projects WHERE name = ?`, s.dialect), name).Scan(&id)
	return id, err
}

// UpsertDedupBuildDir регистрирует каталог build_*.
func (s *Storage) UpsertDedupBuildDir(projectID int64, dirPath string, dirBuildNum int) (int64, error) {
	if s.dialect == DialectPostgres {
		var id int64
		err := s.db.QueryRow(rebind(`
			INSERT INTO dedup_build_dirs (project_id, dir_path, dir_build_num, status)
			VALUES (?, ?, ?, 'pending')
			ON CONFLICT (dir_path) DO UPDATE SET dir_build_num = EXCLUDED.dir_build_num
			RETURNING id
		`, s.dialect), projectID, dirPath, dirBuildNum).Scan(&id)
		return id, err
	}
	_, err := s.db.Exec(rebind(`
		INSERT INTO dedup_build_dirs (project_id, dir_path, dir_build_num, status)
		VALUES (?, ?, ?, 'pending')
		ON CONFLICT(dir_path) DO UPDATE SET dir_build_num = excluded.dir_build_num
	`, s.dialect), projectID, dirPath, dirBuildNum)
	if err != nil {
		return 0, err
	}
	var id int64
	err = s.db.QueryRow(rebind(`SELECT id FROM dedup_build_dirs WHERE dir_path = ?`, s.dialect), dirPath).Scan(&id)
	return id, err
}

// UpsertDedupFile регистрирует .debug файл для dedup.
func (s *Storage) UpsertDedupFile(f DedupFile) (int64, error) {
	q := rebind(`
		INSERT INTO dedup_files (
			build_dir_id, file_path, filename, file_stem, version,
			file_build_num, commit_tag, original_size, status
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
		ON CONFLICT(file_path) DO UPDATE SET
			commit_tag = excluded.commit_tag,
			original_size = excluded.original_size,
			status = CASE
				WHEN dedup_files.storage_kind IN ('full', 'compressed', 'ref') AND dedup_files.delta_path = '' THEN 'pending'
				WHEN dedup_files.storage_kind IN ('base', 'delta') THEN 'pending'
				ELSE dedup_files.status
			END,
			storage_kind = CASE
				WHEN dedup_files.storage_kind IN ('base', 'delta') THEN 'full'
				ELSE dedup_files.storage_kind
			END
	`, s.dialect)
	if s.dialect == DialectPostgres {
		q = rebind(`
			INSERT INTO dedup_files (
				build_dir_id, file_path, filename, file_stem, version,
				file_build_num, commit_tag, original_size, status
			) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')
			ON CONFLICT (file_path) DO UPDATE SET
				commit_tag = EXCLUDED.commit_tag,
				original_size = EXCLUDED.original_size,
				status = CASE
					WHEN dedup_files.storage_kind IN ('full', 'compressed', 'ref') AND dedup_files.delta_path = '' THEN 'pending'
					WHEN dedup_files.storage_kind IN ('base', 'delta') THEN 'pending'
					ELSE dedup_files.status
				END,
				storage_kind = CASE
					WHEN dedup_files.storage_kind IN ('base', 'delta') THEN 'full'
					ELSE dedup_files.storage_kind
				END
			RETURNING id
		`, s.dialect)
		var id int64
		err := s.db.QueryRow(q,
			f.BuildDirID, f.FilePath, f.Filename, f.FileStem, f.Version,
			f.FileBuildNum, f.CommitTag, f.OriginalSize,
		).Scan(&id)
		return id, err
	}
	_, err := s.db.Exec(q,
		f.BuildDirID, f.FilePath, f.Filename, f.FileStem, f.Version,
		f.FileBuildNum, f.CommitTag, f.OriginalSize,
	)
	if err != nil {
		return 0, err
	}
	var id int64
	err = s.db.QueryRow(rebind(`SELECT id FROM dedup_files WHERE file_path = ?`, s.dialect), f.FilePath).Scan(&id)
	return id, err
}

// ListPendingBuildDirs возвращает каталоги build_* со статусом pending.
func (s *Storage) ListPendingBuildDirs(projectName string, limit int) ([]DedupBuildDir, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := s.db.Query(rebind(`
		SELECT b.id, b.project_id, p.name, b.dir_path, b.dir_build_num,
			b.status, b.error_msg, b.processed_at
		FROM dedup_build_dirs b
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE b.status = 'pending' AND (? = '' OR p.name = ?)
		ORDER BY b.dir_build_num
		LIMIT ?
	`, s.dialect), projectName, projectName, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanBuildDirs(rows)
}

// ListPendingDedupFiles возвращает файлы pending в указанных build dirs.
func (s *Storage) ListPendingDedupFiles(buildDirIDs []int64) ([]DedupFile, error) {
	if len(buildDirIDs) == 0 {
		return nil, nil
	}
	placeholders, args := inClause(buildDirIDs)
	q := fmt.Sprintf(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.status = 'pending' AND f.build_dir_id IN (%s)
	`, placeholders)
	rows, err := s.db.Query(rebind(q, s.dialect), args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanDedupFiles(rows)
}

// ListPendingDedupFilesByProject — все pending файлы проекта для группировки.
func (s *Storage) ListPendingDedupFilesByProject(projectName string) ([]DedupFile, error) {
	rows, err := s.db.Query(rebind(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.status = 'pending' AND p.name = ?
		ORDER BY f.file_build_num
	`, s.dialect), projectName)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanDedupFiles(rows)
}

// ListAllPendingDedupFiles возвращает все pending-файлы для глобальной группировки.
func (s *Storage) ListAllPendingDedupFiles() ([]DedupFile, error) {
	rows, err := s.db.Query(rebind(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.status = 'pending'
		ORDER BY p.name, f.file_build_num
	`, s.dialect))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanDedupFiles(rows)
}

// GetDedupFileByPath возвращает метаданные dedup по пути файла.
func (s *Storage) GetDedupFileByPath(filePath string) (DedupFile, error) {
	return lookupDedupByPath(s, filePath)
}

// GetDedupFileByID загружает запись по id.
func (s *Storage) GetDedupFileByID(id int64) (DedupFile, error) {
	rows, err := s.db.Query(rebind(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.id = ?
	`, s.dialect), id)
	if err != nil {
		return DedupFile{}, err
	}
	defer rows.Close()
	files, err := scanDedupFiles(rows)
	if err != nil || len(files) == 0 {
		return DedupFile{}, ErrNotFound
	}
	return files[0], nil
}

// MarkDedupFileDone обновляет статус файла после успешного dedup.
func (s *Storage) MarkDedupFileDone(id int64, kind DedupStorageKind, baseID int64, blobPath, sha256 string, compressedSize int64) error {
	var base sql.NullInt64
	if baseID > 0 {
		base = sql.NullInt64{Int64: baseID, Valid: true}
	}
	_, err := s.db.Exec(rebind(`
		UPDATE dedup_files SET
			storage_kind = ?, base_file_id = ?, delta_path = ?,
			sha256 = ?, compressed_size = ?, status = 'done', error_msg = ''
		WHERE id = ?
	`, s.dialect), string(kind), base, blobPath, sha256, compressedSize, id)
	return err
}

// UpdateDedupFileCompressedSize обновляет compressed_size (например после objcopy zstd на base).
func (s *Storage) UpdateDedupFileCompressedSize(id int64, compressedSize int64) error {
	_, err := s.db.Exec(rebind(`
		UPDATE dedup_files SET compressed_size = ? WHERE id = ?
	`, s.dialect), compressedSize, id)
	return err
}

// FindBlobPathBySHA возвращает путь существующего blob по SHA256 содержимого.
func (s *Storage) FindBlobPathBySHA(sha string) (string, error) {
	if sha == "" {
		return "", nil
	}
	var blobPath string
	err := s.db.QueryRow(rebind(`
		SELECT delta_path FROM dedup_files
		WHERE sha256 = ? AND status = 'done'
			AND storage_kind IN ('compressed', 'ref')
			AND delta_path != ''
		ORDER BY id ASC
		LIMIT 1
	`, s.dialect), sha).Scan(&blobPath)
	if err == sql.ErrNoRows {
		return "", nil
	}
	return blobPath, err
}

// MarkDedupFileError сохраняет ошибку обработки файла.
func (s *Storage) MarkDedupFileError(id int64, msg string) error {
	_, err := s.db.Exec(rebind(`
		UPDATE dedup_files SET status = 'error', error_msg = ? WHERE id = ?
	`, s.dialect), msg, id)
	return err
}

// MarkDedupBuildDirDone помечает каталог build_* обработанным.
func (s *Storage) MarkDedupBuildDirDone(id int64) error {
	_, err := s.db.Exec(rebind(`
		UPDATE dedup_build_dirs SET status = 'done', processed_at = ?, error_msg = ''
		WHERE id = ?
	`, s.dialect), time.Now().Unix(), id)
	return err
}

// MarkDedupBuildDirError сохраняет ошибку каталога.
func (s *Storage) MarkDedupBuildDirError(id int64, msg string) error {
	_, err := s.db.Exec(rebind(`
		UPDATE dedup_build_dirs SET status = 'error', error_msg = ?, processed_at = ?
		WHERE id = ?
	`, s.dialect), msg, time.Now().Unix(), id)
	return err
}

// SetDedupBuildDirStatus устанавливает статус каталога.
func (s *Storage) SetDedupBuildDirStatus(id int64, status DedupBuildStatus) error {
	_, err := s.db.Exec(rebind(`UPDATE dedup_build_dirs SET status = ? WHERE id = ?`, s.dialect), string(status), id)
	return err
}

// ListDedupProjectNames возвращает отсортированные имена обнаруженных папок-проектов.
func (s *Storage) ListDedupProjectNames() ([]string, error) {
	rows, err := s.db.Query(rebind(`SELECT name FROM dedup_projects ORDER BY name`, s.dialect))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var name string
		if err := rows.Scan(&name); err != nil {
			return nil, err
		}
		out = append(out, name)
	}
	if out == nil {
		out = []string{}
	}
	return out, rows.Err()
}

// DedupProjectTotals — сводка dedup по папке для Web UI.
type DedupProjectTotals struct {
	Project         string  `json:"project"`
	BuildDirs       int64   `json:"build_dirs"`
	FilesDone       int64   `json:"files_done"`
	FilesBase       int64   `json:"files_base"`
	FilesDelta      int64   `json:"files_delta"`
	FilesFull       int64   `json:"files_full"`
	FilesCompressed int64   `json:"files_compressed"` // legacy zstd CAS
	FilesCASRef     int64   `json:"files_cas_ref"`    // legacy zstd CAS ref
	BytesOriginal   int64   `json:"bytes_original"`
	BytesOnDisk     int64   `json:"bytes_on_disk"`
	BytesSaved      int64   `json:"bytes_saved"`
	SavedPercent    float64 `json:"saved_percent"`
}

// DedupTotalsByProject возвращает статистику dedup, сгруппированную по папке.
func (s *Storage) DedupTotalsByProject() ([]DedupProjectTotals, error) {
	names, err := s.ListDedupProjectNames()
	if err != nil {
		return nil, err
	}
	out := make([]DedupProjectTotals, 0, len(names))
	for _, name := range names {
		t, err := s.dedupTotalsForProject(name)
		if err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, nil
}

func (s *Storage) dedupTotalsForProject(projectName string) (DedupProjectTotals, error) {
	var t DedupProjectTotals
	t.Project = projectName

	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_build_dirs b
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ?
	`, s.dialect), projectName).Scan(&t.BuildDirs)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.status = 'done'
	`, s.dialect), projectName).Scan(&t.FilesDone)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.storage_kind = 'base'
	`, s.dialect), projectName).Scan(&t.FilesBase)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.storage_kind = 'delta'
	`, s.dialect), projectName).Scan(&t.FilesDelta)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.storage_kind = 'full'
	`, s.dialect), projectName).Scan(&t.FilesFull)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.storage_kind = 'compressed'
	`, s.dialect), projectName).Scan(&t.FilesCompressed)
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.storage_kind = 'ref'
	`, s.dialect), projectName).Scan(&t.FilesCASRef)
	_ = s.db.QueryRow(rebind(`
		SELECT COALESCE(SUM(f.original_size), 0) FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.status = 'done'
	`, s.dialect), projectName).Scan(&t.BytesOriginal)

	rows, err := s.db.Query(rebind(`
		SELECT f.storage_kind, f.file_path, f.delta_path, f.original_size, f.compressed_size
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE p.name = ? AND f.status = 'done'
	`, s.dialect), projectName)
	if err != nil {
		return t, err
	}
	defer rows.Close()
	for rows.Next() {
		var kind, filePath, blobPath string
		var origSize, compSize int64
		if err := rows.Scan(&kind, &filePath, &blobPath, &origSize, &compSize); err != nil {
			return t, err
		}
		switch DedupStorageKind(kind) {
		case DedupKindRef:
			// blob уже учтён у canonical compressed-записи
		default:
			t.BytesOnDisk += dedupFileBytesOnDisk(DedupStorageKind(kind), filePath, blobPath, origSize, compSize)
		}
	}
	if err := rows.Err(); err != nil {
		return t, err
	}
	if t.BytesOriginal > 0 && t.BytesOnDisk < t.BytesOriginal {
		t.BytesSaved = t.BytesOriginal - t.BytesOnDisk
		t.SavedPercent = float64(t.BytesSaved) / float64(t.BytesOriginal) * 100
	}
	return t, nil
}

// DedupStats — агрегаты для мониторинга dedup.
type DedupStats struct {
	FilesTotal      int64
	FilesPending    int64
	FilesDone       int64
	FilesBase       int64
	FilesDelta      int64
	FilesFull       int64
	FilesCompressed int64
	FilesCASRef     int64
	BytesOriginal   int64
	BytesCompressed int64
}

// DedupStats возвращает счётчики dedup.
func (s *Storage) DedupStats() (DedupStats, error) {
	var st DedupStats
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files`, s.dialect)).Scan(&st.FilesTotal)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE status = 'pending'`, s.dialect)).Scan(&st.FilesPending)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE status = 'done'`, s.dialect)).Scan(&st.FilesDone)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE storage_kind = 'base'`, s.dialect)).Scan(&st.FilesBase)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE storage_kind = 'delta'`, s.dialect)).Scan(&st.FilesDelta)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE storage_kind = 'full'`, s.dialect)).Scan(&st.FilesFull)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE storage_kind = 'compressed'`, s.dialect)).Scan(&st.FilesCompressed)
	_ = s.db.QueryRow(rebind(`SELECT COUNT(1) FROM dedup_files WHERE storage_kind = 'ref'`, s.dialect)).Scan(&st.FilesCASRef)
	_ = s.db.QueryRow(rebind(`SELECT COALESCE(SUM(original_size), 0) FROM dedup_files`, s.dialect)).Scan(&st.BytesOriginal)
	_ = s.db.QueryRow(rebind(`
		SELECT COALESCE(SUM(compressed_size), 0) FROM dedup_files
		WHERE storage_kind IN ('compressed', 'ref', 'delta') AND status = 'done'
	`, s.dialect)).Scan(&st.BytesCompressed)
	return st, nil
}

func dedupFileBytesOnDisk(kind DedupStorageKind, filePath, blobPath string, origSize, compSize int64) int64 {
	switch kind {
	case DedupKindCompressed, DedupKindDelta:
		if compSize > 0 {
			return compSize
		}
		if st, err := fileSize(blobPath); err == nil {
			return st
		}
	case DedupKindBase, DedupKindFull:
		if st, err := fileSize(filePath); err == nil {
			return st
		}
		return origSize
	}
	return 0
}

func scanBuildDirs(rows *sql.Rows) ([]DedupBuildDir, error) {
	var out []DedupBuildDir
	for rows.Next() {
		var b DedupBuildDir
		var processed int64
		if err := rows.Scan(
			&b.ID, &b.ProjectID, &b.ProjectName, &b.DirPath, &b.DirBuildNum,
			&b.Status, &b.ErrorMsg, &processed,
		); err != nil {
			return nil, err
		}
		if processed > 0 {
			b.ProcessedAt = time.Unix(processed, 0)
		}
		out = append(out, b)
	}
	return out, rows.Err()
}

func scanDedupFiles(rows *sql.Rows) ([]DedupFile, error) {
	var out []DedupFile
	for rows.Next() {
		var f DedupFile
		if err := rows.Scan(
			&f.ID, &f.BuildDirID, &f.ProjectName, &f.FilePath, &f.Filename,
			&f.FileStem, &f.Version, &f.FileBuildNum, &f.CommitTag,
			&f.StorageKind, &f.BaseFileID, &f.BlobPath, &f.SHA256,
			&f.OriginalSize, &f.CompressedSize, &f.Status, &f.ErrorMsg,
		); err != nil {
			return nil, err
		}
		out = append(out, f)
	}
	return out, rows.Err()
}

func inClause(ids []int64) (string, []any) {
	ph := make([]string, len(ids))
	args := make([]any, len(ids))
	for i, id := range ids {
		ph[i] = "?"
		args[i] = id
	}
	return joinStrings(ph, ","), args
}

func joinStrings(parts []string, sep string) string {
	if len(parts) == 0 {
		return ""
	}
	out := parts[0]
	for i := 1; i < len(parts); i++ {
		out += sep + parts[i]
	}
	return out
}

// DedupFileSnapshot — лёгкая запись для incremental discover.
type DedupFileSnapshot struct {
	Status       DedupBuildStatus
	OriginalSize int64
	CommitTag    string
}

// GetDedupFileSnapshotByPath возвращает снимок существующей записи dedup.
func (s *Storage) GetDedupFileSnapshotByPath(filePath string) (DedupFileSnapshot, bool, error) {
	var snap DedupFileSnapshot
	err := s.db.QueryRow(rebind(`
		SELECT status, original_size, commit_tag FROM dedup_files WHERE file_path = ?
	`, s.dialect), filePath).Scan(&snap.Status, &snap.OriginalSize, &snap.CommitTag)
	if errors.Is(err, sql.ErrNoRows) {
		return DedupFileSnapshot{}, false, nil
	}
	return snap, true, err
}

// ListDedupFullsByStem возвращает full-файлы для file_stem (самые ранние сборки первыми).
func (s *Storage) ListDedupFullsByStem(fileStem string, limit int) ([]DedupFile, error) {
	if limit <= 0 {
		limit = 32
	}
	rows, err := s.db.Query(rebind(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.file_stem = ? AND f.storage_kind = 'full' AND f.status = 'done'
		ORDER BY f.file_build_num ASC, f.id ASC
		LIMIT ?
	`, s.dialect), fileStem, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanDedupFiles(rows)
}

// ListDedupBasesByStem возвращает base-файлы для file_stem (новые первыми).
func (s *Storage) ListDedupBasesByStem(fileStem string, limit int) ([]DedupFile, error) {
	if limit <= 0 {
		limit = 32
	}
	rows, err := s.db.Query(rebind(`
		SELECT f.id, f.build_dir_id, p.name, f.file_path, f.filename,
			f.file_stem, f.version, f.file_build_num, f.commit_tag,
			f.storage_kind, f.base_file_id, f.delta_path, f.sha256,
			f.original_size, f.compressed_size, f.status, f.error_msg
		FROM dedup_files f
		JOIN dedup_build_dirs b ON b.id = f.build_dir_id
		JOIN dedup_projects p ON p.id = b.project_id
		WHERE f.file_stem = ? AND f.storage_kind = 'base' AND f.status = 'done'
		ORDER BY f.file_build_num DESC, f.id DESC
		LIMIT ?
	`, s.dialect), fileStem, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanDedupFiles(rows)
}

// HasPendingFilesInBuildDir проверяет, остались ли pending файлы в каталоге.
func (s *Storage) HasPendingFilesInBuildDir(buildDirID int64) (bool, error) {
	var n int
	err := s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files WHERE build_dir_id = ? AND status = 'pending'
	`, s.dialect), buildDirID).Scan(&n)
	return n > 0, err
}

// FinishBuildDirIfDone помечает каталог done, если все файлы обработаны.
func (s *Storage) FinishBuildDirIfDone(buildDirID int64) error {
	pending, err := s.HasPendingFilesInBuildDir(buildDirID)
	if err != nil {
		return err
	}
	if pending {
		return nil
	}
	var errCount int
	_ = s.db.QueryRow(rebind(`
		SELECT COUNT(1) FROM dedup_files WHERE build_dir_id = ? AND status = 'error'
	`, s.dialect), buildDirID).Scan(&errCount)
	if errCount > 0 {
		return s.MarkDedupBuildDirError(buildDirID, fmt.Sprintf("%d file(s) failed", errCount))
	}
	return s.MarkDedupBuildDirDone(buildDirID)
}

// ErrDedupConflict — конфликт при обновлении dedup.
var ErrDedupConflict = errors.New("dedup conflict")
